
import Foundation

var peso : Float = 100  //Peso en kilogramos
let altura : Float = 1.70 // Altura en metros
var IMC = peso/pow(altura,2)
print ("Presenta indice de masa corporal(IMC):\(IMC)")
switch IMC {
case ..<15:
    print("Por ende,delgadez muy severa")
case 15..<15.9:
    print("Por ende, delgadez severa")
case 16..<18.4:
    print("Por ende, delgadez")
case 18.5..<24.9:
    print("Presenta Peso saludable")
case 25..<29.9:
    print("Por ende está con sobrepeso")
case 30..<34.9:
    print("Por ende, presenta una obesidad moderada")
case 35..<39.9:
    print("Por ende, presenta una obesidad severda")
default:
    print("Por lo que requiere ir al Nutricionista")

}



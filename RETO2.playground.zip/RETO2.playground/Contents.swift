import Foundation

//DATOS DE ENTRADA

let persona01 = (Nombre: "CARLOS JOSÉ", ApellidoPaterno:"ROBLES",  ApellidoMaterno: "GOMES", FNAC: "1995-08-06", DNI:78451245, sexo:"M", correo: "carlos.roblesg@hotmail.com",NHermanos:2, Usuario:"carlos.robles")

let persona02 = (Nombre: "MIGUEL ANGEL", ApellidoPaterno:"QUISPE",  ApellidoMaterno: "OTERO", FNAC: "1995-12-28", DNI:79451654, sexo:"M", correo: "miguel.anguel@gmail.com",NHermanos:0, Usario:"miguel.angel")

let persona03 = (Nombre: "KARLA ALEXANDRA", ApellidoPaterno:"FLORES",  ApellidoMaterno: "ROSAS", FNAC:"1997-02-15", DNI:77485812, sexo:"F", correo: "karla.alexandra@gmail.com",NHermanos:1, Usario:"karla.alexandra")

let persona04 = (Nombre: "NICOLAS", ApellidoPaterno:"QUISPE",  ApellidoMaterno: "CEVALLOS", FNAC: "1990-10-08", DNI:71748552, sexo:"M", correo: "nicolas123@gmail.com",NHermanos:1, Usuario:"nicolas123")

let persona05 = (Nombre: "PEDRO ANDRE", ApellidoPaterno:"PICASSO",  ApellidoMaterno: "BETANCUR", FNAC:"1994-05-17", DNI:71748552, sexo:"M", correo: "pedroandrepicasso@gmail.com",NHermanos:2, Usuario:"pedroandrepicasso")

let persona06 = (Nombre: "FABIOLA MARIA", ApellidoPaterno:"PALACIO",  ApellidoMaterno: "VEGA", FNAC: "1992-02-02", DNI:76758254, sexo:"F", correo: "fabi@hotmail.com",NHermanos:0, Usuario:"fabi")

// ¿OBTENER LA EDAD DE LAS PERSONAS POR MEDIO DE SU F.NAC?

var dateFormatter : DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        formatter.locale = Locale(identifier: "en_US_POSIX")
        return formatter
    }()


let FNAC1 = dateFormatter.date(from: persona01.3)
let timeInterval1 = FNAC1?.timeIntervalSinceNow
let Edad1 = abs(Int(timeInterval1! / 31556926.0))

let FNAC2 = dateFormatter.date(from: persona02.3)
let timeInterval2 = FNAC2?.timeIntervalSinceNow
let Edad2 = abs(Int(timeInterval2! / 31556926.0))

let FNAC3 = dateFormatter.date(from: persona03.3)
let timeInterval3 = FNAC3?.timeIntervalSinceNow
let Edad3 = abs(Int(timeInterval3! / 31556926.0))

let FNAC4 = dateFormatter.date(from: persona04.3)
let timeInterval4 = FNAC4?.timeIntervalSinceNow
let Edad4 = abs(Int(timeInterval4! / 31556926.0))

let FNAC5 = dateFormatter.date(from: persona05.3)
let timeInterval5 = FNAC5?.timeIntervalSinceNow
let Edad5 = abs(Int(timeInterval5! / 31556926.0))

let FNAC6 = dateFormatter.date(from: persona06.3)
let timeInterval6 = FNAC6?.timeIntervalSinceNow
let Edad6 = abs(Int(timeInterval6! / 31556926.0))

let ListaEdad = [
    persona01.0: Edad1, persona02.0: Edad2,persona03.0: Edad3,
    persona04.0: Edad4, persona05.0: Edad5, persona06.0: Edad6
]

print(ListaEdad)

var PersonaDeMayorEdad = ListaEdad.max{$0.value<$1.value}
var PersonaDeMenorEdad = ListaEdad.max{$0.value<$1.value}

//RESPUESTA 1:

print("La Persona de Mayor Edad es :\(PersonaDeMayorEdad!)")
print("La Persona de Menor Edad es ::\(PersonaDeMenorEdad!)")

var mujeres = [String:String]()
var hombres = [String:String]()

if persona01.5 == "F" {
    mujeres[persona01.Nombre]=persona01.sexo
}else{
    hombres[persona01.Nombre]=persona01.sexo
}
if persona02.sexo == "F" {
    mujeres[persona02.Nombre]=persona02.sexo
}else{
    hombres[persona02.Nombre]=persona02.sexo
}
if persona03.sexo == "F" {
    print(mujeres.count)
    mujeres[persona03.Nombre]=persona03.sexo
}else{
    hombres[persona03.Nombre]=persona03.sexo
}
if persona04.sexo == "F" {
    print(mujeres.count)
    mujeres[persona04.Nombre]=persona04.sexo
}else{
    hombres[persona04.Nombre]=persona04.sexo
}
if persona05.sexo == "F" {
    mujeres[persona05.Nombre]=persona05.sexo
}else{
    hombres[persona05.Nombre]=persona05.sexo
}
if persona06.sexo == "F" {
    mujeres[persona06.Nombre]=persona06.sexo
    
}else{
    hombres[persona06.Nombre]=persona06.sexo
    
}
print(mujeres)
print(hombres)

//RESPUESTA 2

print("El número de hombres son: \(hombres.count)")
print("El número de mujeres son: \(hombres.count)")

//RESPUESTA 3

var personasConMasde2H = [
    String : Int]()

if persona01.NHermanos>=2 {
    personasConMasde2H[persona01.Nombre] = persona01.NHermanos
    
}
if persona02.NHermanos>=2 {
    personasConMasde2H[persona02.Nombre] = persona02.NHermanos
}
if persona03.NHermanos>=2 {
    personasConMasde2H[persona03.Nombre] = persona03.NHermanos
}
if persona04.NHermanos>=2 {
    personasConMasde2H[persona04.Nombre] = persona04.NHermanos
}
if persona05.NHermanos>=2 {
    personasConMasde2H[persona05.Nombre] = persona05.NHermanos
}
if persona06.NHermanos>=2 {
    personasConMasde2H[persona06.Nombre] = persona06.NHermanos
}
//RESPUESTA 3.0

print("Personas con más de 2 Hermanos son: \(personasConMasde2H)")


var persona01Nombre = persona01.Nombre
var persona02Nombre = persona02.Nombre
var persona03Nombre = persona03.Nombre
var persona04Nombre = persona04.Nombre
var persona05Nombre = persona05.Nombre
var persona06Nombre = persona06.Nombre

var persona01APaterno = persona01.Nombre
var persona02APaterno = persona02.ApellidoPaterno
var persona03APaterno = persona03.ApellidoPaterno
var persona04APaterno = persona04.ApellidoPaterno
var persona05APaterno = persona05.ApellidoPaterno
var persona06APaterno = persona06.ApellidoPaterno


var persona01AMaterno = persona01.ApellidoMaterno
var persona02AMaterno = persona02.ApellidoMaterno
var persona03AMaterno = persona03.ApellidoMaterno
var persona04AMaterno = persona04.ApellidoMaterno
var persona05AMaterno = persona05.ApellidoMaterno
var persona06AMaterno = persona06.ApellidoMaterno

extension StringProtocol {
    var firstUppercased: String{prefix(1).uppercased() + dropFirst()}
    var firstCapitalized: String { prefix(1).capitalized + dropFirst()}
}

var nombre1 = persona01Nombre.lowercased().firstUppercased
var nombre2 = persona02Nombre.lowercased().firstUppercased
var nombre3 = persona03Nombre.lowercased().firstUppercased
var nombre4 = persona04Nombre.lowercased().firstUppercased
var nombre5 = persona05Nombre.lowercased().firstUppercased
var nombre6 = persona06Nombre.lowercased().firstUppercased

//Removiendo el segundo nombre de Carlos José.

var a1 = nombre1.index(nombre1.startIndex,offsetBy: 6)
nombre1.remove(at:a1)
var a2 = nombre1.index(nombre1.startIndex,offsetBy: 6)
nombre1.remove(at:a2)
var a3 = nombre1.index(nombre1.startIndex,offsetBy: 6)
nombre1.remove(at:a3)
var a4 = nombre1.index(nombre1.startIndex,offsetBy: 6)
nombre1.remove(at:a4)
var a5 = nombre1.index(nombre1.startIndex,offsetBy: 6)
nombre1.remove(at:a5)


var b1 = nombre2.index(nombre2.startIndex, offsetBy:6)
nombre2.remove(at:b1)
var b2 = nombre2.index(nombre2.startIndex,offsetBy: 6)
nombre2.remove(at:b2)
var b3 = nombre2.index(nombre2.startIndex,offsetBy: 6)
nombre2.remove(at:b3)
var b4 = nombre2.index(nombre2.startIndex,offsetBy: 6)
nombre2.remove(at:b4)
var b5 = nombre2.index(nombre2.startIndex,offsetBy: 6)
nombre2.remove(at:b5)
var b6 = nombre2.index(nombre2.startIndex,offsetBy: 6)
nombre2.remove(at:b6)


var c1 = nombre3.index(nombre3.startIndex, offsetBy:6)
nombre3.remove(at:c1)
var c2 = nombre3.index(nombre3.startIndex,offsetBy: 6)
nombre3.remove(at:c2)
var c3 = nombre3.index(nombre3.startIndex,offsetBy: 6)
nombre3.remove(at:c3)
var c4 = nombre3.index(nombre3.startIndex,offsetBy: 6)
nombre3.remove(at:c4)
var c5 = nombre3.index(nombre3.startIndex,offsetBy: 6)
nombre3.remove(at:c5)
var c6 = nombre3.index(nombre3.startIndex,offsetBy: 6)
nombre3.remove(at:c6)
var c7 = nombre3.index(nombre3.startIndex,offsetBy: 5)
nombre3.remove(at:c7)
var c8 = nombre3.index(nombre3.startIndex,offsetBy: 5)
nombre3.remove(at:c8)
var c9 = nombre3.index(nombre3.startIndex,offsetBy: 5)
nombre3.remove(at:c9)
var c10 = nombre3.index(nombre3.startIndex,offsetBy: 5)
nombre3.remove(at:c10)

var d1 = nombre5.index(nombre5.startIndex, offsetBy:6)
nombre5.remove(at:d1)
var d2 = nombre5.index(nombre5.startIndex,offsetBy: 6)
nombre5.remove(at:d2)
var d3 = nombre4.index(nombre5.startIndex,offsetBy: 6)
nombre5.remove(at:d3)
var d4 = nombre5.index(nombre5.startIndex,offsetBy: 6)
nombre5.remove(at:d4)
var d5 = nombre5.index(nombre5.startIndex,offsetBy: 6)
nombre5.remove(at:d5)

var e1 = nombre6.index(nombre6.startIndex, offsetBy:7)
nombre6.remove(at:e1)
var e2 = nombre6.index(nombre6.startIndex,offsetBy: 7)
nombre6.remove(at:e2)
var e3 = nombre6.index(nombre6.startIndex,offsetBy: 7)
nombre6.remove(at:e3)
var e4 = nombre6.index(nombre6.startIndex,offsetBy: 7)
nombre6.remove(at:e4)
var e5 = nombre6.index(nombre6.startIndex,offsetBy: 7)
nombre6.remove(at:e5)
var e6 = nombre6.index(nombre6.startIndex,offsetBy: 7)
nombre6.remove(at:e6)

print(nombre1) // Solo queda el primer nombre (Carlos)
print(nombre2) // Solo queda el primer nombre (Miguel)
print(nombre3) // Solo queda el primer nombre (Karla)
print(nombre5) // Solo queda el primer nombre (Pedro)
print(nombre6) // Solo queda el primer nombre (Pedro)


//Eliminando todas las minusculas del AP y colocando punto final.

var apellido1 = persona01AMaterno.lowercased().firstUppercased
var borradoletra1ap1 = apellido1.index(apellido1.startIndex, offsetBy: 1)
apellido1.remove(at:borradoletra1ap1)
var borradoletra1ap2 = apellido1.index(apellido1.startIndex, offsetBy: 1)
apellido1.remove(at:borradoletra1ap2)
var borradoletra1ap3 = apellido1.index(apellido1.startIndex, offsetBy: 1)
apellido1.remove(at:borradoletra1ap3)
var borradoletra1ap4 = apellido1.index(apellido1.startIndex, offsetBy: 1)
apellido1.remove(at:borradoletra1ap4)


var apellido2 = persona02AMaterno.lowercased().firstUppercased
var borradoletra2ap1 = apellido2.index(apellido2.startIndex, offsetBy: 1)
apellido2.remove(at:borradoletra2ap1)
var borradoletra2ap2 = apellido2.index(apellido2.startIndex, offsetBy: 1)
apellido2.remove(at:borradoletra2ap2)
var borradoletra2ap3 = apellido2.index(apellido2.startIndex, offsetBy: 1)
apellido2.remove(at:borradoletra2ap3)
var borradoletra2ap4 = apellido2.index(apellido2.startIndex, offsetBy: 1)
apellido2.remove(at:borradoletra2ap4)


var apellido3 = persona03AMaterno.lowercased().firstUppercased
var borradoletra3ap1 = apellido3.index(apellido3.startIndex, offsetBy: 1)
apellido3.remove(at:borradoletra2ap1)
var borradoletra3ap2 = apellido3.index(apellido3.startIndex, offsetBy: 1)
apellido3.remove(at:borradoletra2ap2)
var borradoletra3ap3 = apellido3.index(apellido3.startIndex, offsetBy: 1)
apellido3.remove(at:borradoletra2ap3)
var borradoletra3ap4 = apellido3.index(apellido3.startIndex, offsetBy: 1)
apellido3.remove(at:borradoletra2ap4)

var apellido4 = persona04AMaterno.lowercased().firstUppercased
var borradoletra4ap1 = apellido4.index(apellido4.startIndex, offsetBy: 1)
apellido4.remove(at:borradoletra4ap1)
var borradoletra4ap2 = apellido4.index(apellido4.startIndex, offsetBy: 1)
apellido4.remove(at:borradoletra4ap2)
var borradoletra4ap3 = apellido4.index(apellido4.startIndex, offsetBy: 1)
apellido4.remove(at:borradoletra4ap3)
var borradoletra4ap4 = apellido4.index(apellido4.startIndex, offsetBy: 1)
apellido4.remove(at:borradoletra4ap4)
var borradoletra4ap5 = apellido4.index(apellido4.startIndex, offsetBy: 1)
apellido4.remove(at:borradoletra4ap5)
var borradoletra4ap6 = apellido4.index(apellido4.startIndex, offsetBy: 1)
apellido4.remove(at:borradoletra4ap6)
var borradoletra4ap7 = apellido4.index(apellido4.startIndex, offsetBy: 1)
apellido4.remove(at:borradoletra4ap7)


var apellido5 = persona05AMaterno.lowercased().firstUppercased
var borradoletra5ap1 = apellido5.index(apellido5.startIndex, offsetBy: 1)
apellido5.remove(at:borradoletra5ap1)
var borradoletra5ap2 = apellido5.index(apellido5.startIndex, offsetBy: 1)
apellido5.remove(at:borradoletra5ap2)
var borradoletra5ap3 = apellido5.index(apellido5.startIndex, offsetBy: 1)
apellido5.remove(at:borradoletra5ap3)
var borradoletra5ap4 = apellido5.index(apellido5.startIndex, offsetBy: 1)
apellido5.remove(at:borradoletra5ap4)
var borradoletra5ap5 = apellido5.index(apellido5.startIndex, offsetBy: 1)
apellido5.remove(at:borradoletra5ap5)
var borradoletra5ap6 = apellido5.index(apellido5.startIndex, offsetBy: 1)
apellido5.remove(at:borradoletra5ap6)
var borradoletra5ap7 = apellido4.index(apellido4.startIndex, offsetBy: 1)
apellido5.remove(at:borradoletra5ap7)


var apellido6 = persona06AMaterno.lowercased().firstUppercased
var borradoletra6ap1 = apellido6.index(apellido6.startIndex, offsetBy: 1)
apellido6.remove(at:borradoletra6ap1)
var borradoletra6ap2 = apellido6.index(apellido6.startIndex, offsetBy: 1)
apellido6.remove(at:borradoletra6ap2)
var borradoletra6ap3 = apellido6.index(apellido6.startIndex, offsetBy: 1)
apellido6.remove(at:borradoletra6ap3)
var borradoletra6ap4 = apellido6.index(apellido6.startIndex, offsetBy: 1)

//agregando el punto.

//RESPUESTA 3
apellido1.insert(".", at: apellido1.endIndex)
apellido2.insert(".", at: apellido2.endIndex)
apellido3.insert(".", at: apellido3.endIndex)
apellido4.insert(".", at: apellido4.endIndex)
apellido5.insert(".", at: apellido5.endIndex)
apellido6.insert(".", at: apellido6.endIndex)

//RESPUESTA 4

print(nombre1 + " " + persona01APaterno.lowercased().firstUppercased + " " + apellido1)

print(nombre2 + " " + persona02APaterno.lowercased().firstUppercased + " " + apellido2)

print(nombre3 + " " + persona02APaterno.lowercased().firstUppercased + " " + apellido3)
print(nombre4 + " " + persona02APaterno.lowercased().firstUppercased + " " + apellido4)

print(nombre5 + " " + persona02APaterno.lowercased().firstUppercased + " " + apellido5)

print(nombre6 + " " + persona02APaterno.lowercased().firstUppercased + " " + apellido6)
